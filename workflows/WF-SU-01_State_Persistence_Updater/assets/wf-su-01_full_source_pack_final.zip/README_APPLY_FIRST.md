# README_APPLY_FIRST — WF-SU-01

## Read order
1. `docs/ucenicul_claude_handoff_hardened/11_STAGE_WF-SU-01.md`
2. `docs/ucenicul_claude_handoff_hardened/CURRENT_STAGE__WF-SU-01.md`
3. `workflows/WF-SU-01_IMPORT_PATCH_PLAN.md`
4. `workflows/WF-SU-01_TEST_MATRIX.md`
5. `CLAUDE_PROMPT__WF-SU-01.txt`

## Import posture
- This pack is **pre_live_ready**, not closed.
- Import first, then verify shell, then run V1–V6.
- Do not use full-body workflow PUT after import.
- Preserve queryReplacement bindings and alwaysOutputData on the relevant Postgres nodes.

## Live-test hooks intentionally shipped in this pack
To keep the pack autonomous and not dependent on extra live tables, two explicit envelope hooks are canonical for manual pinData tests:
- `_write_permission_override` — lets the verifier deny one or more write classes live for V4.
- `_replay_seen_input_hash` — lets the verifier simulate replay-block conditions live for V5.

These hooks are test-only. They do not change the canonical upstream/downstream contracts and they do not add hidden business writes.
