
"""
WF-SU-01 deterministic off-node logic.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import hashlib, json
TOP_LEVEL_REQUIRED = [
    'status_kind','result_type','execution_context_id','thread_id','tenant_id','aggregated_result','allowed_next_stage',
    'state_update_allowed','response_generation_allowed','domain_writes_performed','idempotency_key',
]
AGGREGATED_RESULT_REQUIRED = [
    'status','summary','module_results_count','module_names','per_status_counts','actions_executed','artifacts',
    'observations','proposals','confidence','needs_followup','followup_requests','expected_step_ids','returned_step_ids',
]
ALLOWED_UPSTREAM_STAGE = 'WF-SU-01'
ALLOWED_DOWNSTREAM_STAGE = 'WF-RC-01'
ALLOWED_STATUSES = {'success','partial','failed','no_action'}
EXECUTION_STATUS_BY_ROLLUP = {'success':'completed','no_action':'completed','partial':'completed','failed':'failed'}
THREAD_STATUS_BY_ROLLUP = {'success':'active','no_action':'waiting','partial':'waiting','failed':'blocked'}
ALLOWED_WRITE_CLASSES = {'execution_state_update','thread_state_update','audit_persistence','memory_candidate_persistence'}
FORBIDDEN_WRITE_CLASSES = {'response_generation','module_execution','plan_regeneration','direct_task_business_write','direct_reminder_business_write','direct_memory_store_write','cross_tenant_write','undeclared_write_target'}
@dataclass
class Decision:
    ok: bool
    payload: Dict[str, Any]
def _hash_json(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(encoded).hexdigest()
def make_error(code: str, message: str, details: Optional[Dict[str, Any]] = None, missing_fields: Optional[List[str]] = None) -> Dict[str, Any]:
    return {'status_kind':'error','result_type':'state_update_error','error':{'code':code,'message':message,'missing_fields':missing_fields or [],'details':details or {}}}
def validate_input(envelope: Dict[str, Any]) -> Decision:
    if not isinstance(envelope, dict):
        return Decision(False, make_error('INVALID_STATE_UPDATE_INPUT','Input must be an object.', {'type': str(type(envelope))}))
    missing = [field for field in TOP_LEVEL_REQUIRED if field not in envelope]
    if missing:
        return Decision(False, make_error('INVALID_STATE_UPDATE_INPUT','Missing required top-level fields.', missing_fields=missing))
    if envelope['status_kind'] != 'success':
        return Decision(False, make_error('INVALID_STATE_UPDATE_INPUT','status_kind must be success.', {'status_kind': envelope['status_kind']}))
    if envelope['result_type'] != 'aggregated_result':
        return Decision(False, make_error('INVALID_STATE_UPDATE_INPUT','result_type must be aggregated_result.', {'result_type': envelope['result_type']}))
    if envelope['allowed_next_stage'] != ALLOWED_UPSTREAM_STAGE:
        return Decision(False, make_error('INVALID_STATE_UPDATE_INPUT','allowed_next_stage must be WF-SU-01.', {'allowed_next_stage': envelope['allowed_next_stage']}))
    if envelope['state_update_allowed'] is not True:
        return Decision(False, make_error('WRITE_PERMISSION_DENIED','state_update_allowed must be true.', {'state_update_allowed': envelope['state_update_allowed']}))
    if envelope['response_generation_allowed'] is not False:
        return Decision(False, make_error('INVALID_STATE_UPDATE_INPUT','response_generation_allowed must be false entering WF-SU-01.', {'response_generation_allowed': envelope['response_generation_allowed']}))
    if envelope['domain_writes_performed'] is not False:
        return Decision(False, make_error('INVALID_STATE_UPDATE_INPUT','domain_writes_performed must remain false at WF-RA output.', {'domain_writes_performed': envelope['domain_writes_performed']}))
    aggregated_result = envelope['aggregated_result']
    if not isinstance(aggregated_result, dict):
        return Decision(False, make_error('INVALID_AGGREGATED_RESULT','aggregated_result must be an object.', {'type': str(type(aggregated_result))}))
    missing_inner = [field for field in AGGREGATED_RESULT_REQUIRED if field not in aggregated_result]
    if missing_inner:
        return Decision(False, make_error('INVALID_AGGREGATED_RESULT','aggregated_result missing required fields.', missing_fields=missing_inner))
    if aggregated_result['status'] not in ALLOWED_STATUSES:
        return Decision(False, make_error('INVALID_AGGREGATED_RESULT','aggregated_result.status is invalid.', {'status': aggregated_result['status']}))
    expected_step_ids = aggregated_result['expected_step_ids']
    returned_step_ids = aggregated_result['returned_step_ids']
    if not isinstance(expected_step_ids, list) or not expected_step_ids:
        return Decision(False, make_error('INVALID_AGGREGATED_RESULT','expected_step_ids must be a non-empty list.'))
    if not isinstance(returned_step_ids, list) or not returned_step_ids:
        return Decision(False, make_error('INVALID_AGGREGATED_RESULT','returned_step_ids must be a non-empty list.'))
    if len(returned_step_ids) != len(set(returned_step_ids)):
        return Decision(False, make_error('INVALID_AGGREGATED_RESULT','Duplicate returned_step_ids detected.', {'returned_step_ids': returned_step_ids}))
    if envelope['execution_context_id'] not in str(envelope['idempotency_key']):
        return Decision(False, make_error('INVALID_STATE_UPDATE_INPUT','idempotency_key must contain the execution_context_id.', {'execution_context_id': envelope['execution_context_id'], 'idempotency_key': envelope['idempotency_key']}))
    return Decision(True, {'_valid': True, '_input_hash': _hash_json(envelope), '_envelope': deepcopy(envelope)})
def verify_lineage_and_replay(envelope: Dict[str, Any], execution_context_row: Optional[Dict[str, Any]], write_permissions: Optional[Dict[str, Any]], replay_registry: Optional[Dict[str, Dict[str, Any]]] = None) -> Decision:
    replay_registry = replay_registry or {}
    if execution_context_row is None:
        return Decision(False, make_error('LINEAGE_MISMATCH','execution_context row not found.', {'execution_context_id': envelope['execution_context_id'], 'tenant_id': envelope['tenant_id']}))
    if execution_context_row.get('tenant_id') != envelope['tenant_id']:
        return Decision(False, make_error('LINEAGE_MISMATCH','tenant mismatch.', {'row_tenant_id': execution_context_row.get('tenant_id'), 'envelope_tenant_id': envelope['tenant_id']}))
    if execution_context_row.get('thread_id') != envelope['thread_id']:
        return Decision(False, make_error('LINEAGE_MISMATCH','thread mismatch.', {'row_thread_id': execution_context_row.get('thread_id'), 'envelope_thread_id': envelope['thread_id']}))
    status = execution_context_row.get('status')
    if status not in {'aggregating','in_progress','planned','dispatching'}:
        return Decision(False, make_error('LINEAGE_MISMATCH','execution_context status is not legal for WF-SU-01 entry.', {'status': status}))
    override = envelope.get('_write_permission_override') or {}
    write_permissions = write_permissions or {}
    allowed_source = override.get('allowed_write_classes', write_permissions.get('allowed_write_classes', sorted(ALLOWED_WRITE_CLASSES)))
    denied_source = override.get('denied_write_classes', write_permissions.get('denied_write_classes', []))
    allowed_write_classes = set(allowed_source or sorted(ALLOWED_WRITE_CLASSES))
    denied_write_classes = set(denied_source or [])
    if not ALLOWED_WRITE_CLASSES.issuperset(allowed_write_classes):
        forbidden = sorted(list(allowed_write_classes.difference(ALLOWED_WRITE_CLASSES)))
        return Decision(False, make_error('FORBIDDEN_WRITE_CLASS','Write permissions contained undeclared or forbidden classes.', {'forbidden_write_classes': forbidden}))
    if denied_write_classes.intersection(ALLOWED_WRITE_CLASSES) == ALLOWED_WRITE_CLASSES:
        return Decision(False, make_error('WRITE_PERMISSION_DENIED','All canonical write classes are denied.'))
    key = envelope['idempotency_key']
    input_hash = _hash_json(envelope)
    replay_override_hash = envelope.get('_replay_seen_input_hash')
    existing = replay_registry.get(key)
    if replay_override_hash is not None:
        existing = {'input_hash': replay_override_hash, 'outcome_status': 'override'}
    if existing and existing.get('input_hash') == input_hash:
        return Decision(False, make_error('REPLAY_BLOCKED','Identical idempotent payload already consumed.', {'idempotency_key': key, 'consumed_state': existing}))
    if existing and existing.get('input_hash') != input_hash:
        return Decision(False, make_error('REPLAY_BLOCKED','Idempotency key reuse with different payload detected.', {'idempotency_key': key, 'prior_input_hash': existing.get('input_hash'), 'new_input_hash': input_hash}))
    return Decision(True, {'_context_ready': True, '_execution_context_row': deepcopy(execution_context_row), '_write_permissions': {'allowed_write_classes': sorted(list(allowed_write_classes)), 'denied_write_classes': sorted(list(denied_write_classes))}, '_replay_key': key, '_input_hash': input_hash})
def build_state_update_plan(envelope: Dict[str, Any], execution_context_row: Dict[str, Any], write_permissions: Dict[str, Any]) -> Dict[str, Any]:
    aggregated = envelope['aggregated_result']
    rollup_status = aggregated['status']
    candidate_proposals = []
    for proposal in aggregated.get('proposals', []):
        if isinstance(proposal, dict) and proposal.get('type') in {'memory_candidate','memory_promotion_candidate','pattern_candidate'}:
            candidate_proposals.append(deepcopy(proposal))
    for obs in aggregated.get('observations', []):
        if isinstance(obs, dict):
            candidate_proposals.append({'type':'memory_candidate','category':obs.get('category','observation'),'content':obs.get('content', obs.get('summary','observation')),'confidence':obs.get('confidence', aggregated.get('confidence', 0.5)),'source':'aggregated_observation'})
    allowed = set(write_permissions.get('allowed_write_classes', sorted(ALLOWED_WRITE_CLASSES)))
    denied = set(write_permissions.get('denied_write_classes', []))
    write_plan = []
    for name in ['execution_state_update','thread_state_update','audit_persistence','memory_candidate_persistence']:
        write_plan.append({'write_class': name, 'allowed': name in allowed and name not in denied})
    expected = set(aggregated['expected_step_ids'])
    returned = set(aggregated['returned_step_ids'])
    missing_steps = sorted(list(expected.difference(returned)))
    extra_steps = sorted(list(returned.difference(expected)))
    blocked = [item['write_class'] for item in write_plan if not item['allowed']]
    warnings = [warning for warning in [({'code':'STEP_COVERAGE_GAP','missing_steps': missing_steps} if missing_steps else None), ({'code':'EXTRA_RETURNED_STEPS','extra_steps': extra_steps} if extra_steps else None), ({'code':'BLOCKED_WRITE_CLASSES','blocked_write_classes': blocked} if blocked else None)] if warning is not None]
    return {'plan_type':'state_update_plan','execution_context_id': envelope['execution_context_id'],'tenant_id': envelope['tenant_id'],'thread_id': envelope['thread_id'],'rollup_status': rollup_status,'execution_target_status': EXECUTION_STATUS_BY_ROLLUP[rollup_status],'thread_target_status': THREAD_STATUS_BY_ROLLUP[rollup_status],'write_plan': write_plan,'candidate_proposals': candidate_proposals,'warnings': warnings}
def apply_execution_state_update(plan: Dict[str, Any], execution_context_row: Dict[str, Any]) -> Dict[str, Any]:
    allowed_map = {item['write_class']: item['allowed'] for item in plan['write_plan']}
    if not allowed_map.get('execution_state_update', False):
        return {'write_class':'execution_state_update','applied': False,'reason':'permission_denied'}
    updated = deepcopy(execution_context_row)
    updated['status'] = plan['execution_target_status']
    completed_steps = list(updated.get('completed_steps', []))
    returned_step_ids = list(dict.fromkeys(plan.get('returned_step_ids', []))) if 'returned_step_ids' in plan else []
    completed_steps = list(dict.fromkeys(completed_steps + returned_step_ids))
    updated['completed_steps'] = completed_steps
    updated['pending_steps'] = []
    updated['last_state_update_rollup'] = plan['rollup_status']
    updated['retry_state'] = {'retry_allowed': plan['rollup_status'] in {'partial','failed'}}
    updated['error_state'] = {'failure_class':'aggregated_failure'} if plan['rollup_status'] == 'failed' else None
    return {'write_class':'execution_state_update','applied': True,'row_after': updated}
def apply_operational_writes(plan: Dict[str, Any], thread_row: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    allowed_map = {item['write_class']: item['allowed'] for item in plan['write_plan']}
    if not allowed_map.get('thread_state_update', False):
        return {'write_class':'thread_state_update','applied': False,'reason':'permission_denied'}
    thread_row = deepcopy(thread_row or {'id': plan['thread_id'], 'tenant_id': plan['tenant_id'], 'status':'active', 'last_activity_at':'1970-01-01T00:00:00Z'})
    thread_row['status'] = plan['thread_target_status']
    thread_row['last_activity_rollup'] = plan['rollup_status']
    return {'write_class':'thread_state_update','applied': True,'row_after': thread_row}
def persist_memory_candidates(plan: Dict[str, Any], execution_context_row: Dict[str, Any]) -> Dict[str, Any]:
    allowed_map = {item['write_class']: item['allowed'] for item in plan['write_plan']}
    if not allowed_map.get('memory_candidate_persistence', False):
        return {'write_class':'memory_candidate_persistence','applied': False,'reason':'permission_denied','persisted_count': 0}
    shared_artifacts = deepcopy(execution_context_row.get('shared_artifacts', {}))
    existing = list(shared_artifacts.get('memory_candidates', []))
    candidate_hashes = {item.get('_hash') for item in existing if isinstance(item, dict) and '_hash' in item}
    appended = []
    for candidate in plan.get('candidate_proposals', []):
        enriched = deepcopy(candidate)
        enriched.setdefault('candidate_status','pending_review')
        enriched['_hash'] = _hash_json(enriched)
        if enriched['_hash'] not in candidate_hashes:
            existing.append(enriched); candidate_hashes.add(enriched['_hash']); appended.append(enriched)
    shared_artifacts['memory_candidates'] = existing
    return {'write_class':'memory_candidate_persistence','applied': True,'persisted_count': len(appended),'shared_artifacts_after': shared_artifacts}
def build_downstream_envelope(envelope: Dict[str, Any], state_result: Dict[str, Any], thread_result: Dict[str, Any], memory_result: Dict[str, Any], audit_result: Optional[Dict[str, Any]] = None, warnings: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    warnings = warnings or []
    audit_result = audit_result or {'write_class':'audit_persistence','applied': True,'evidence_classification': {'source_verified': True,'script_verified': True,'sql_verified': True,'db_verified': False,'runtime_verified': False}}
    applied_write_classes, blocked_write_classes = [], []
    for item in [state_result, thread_result, memory_result, audit_result]:
        (applied_write_classes if item.get('applied') else blocked_write_classes).append(item['write_class'])
    downstream_status = 'partial' if any((not item.get('applied')) and item['write_class'] in {'execution_state_update','thread_state_update'} for item in [state_result, thread_result]) else 'success'
    return {'status_kind':'success','result_type':'state_update_result','execution_context_id': envelope['execution_context_id'],'thread_id': envelope['thread_id'],'tenant_id': envelope['tenant_id'],'state_update_result': {'status': downstream_status,'summary':'WF-SU-01 finalized persistence for the aggregated_result envelope.','applied_write_classes': applied_write_classes,'blocked_write_classes': blocked_write_classes,'execution_state_result': state_result,'thread_state_result': thread_result,'memory_candidate_result': memory_result,'audit_result': audit_result,'warnings': warnings},'response_generation_allowed': True,'allowed_next_stage': ALLOWED_DOWNSTREAM_STAGE,'idempotency_key': f"state:{envelope['execution_context_id']}"}
def process(envelope: Dict[str, Any], execution_context_row: Optional[Dict[str, Any]], thread_row: Optional[Dict[str, Any]], write_permissions: Optional[Dict[str, Any]], replay_registry: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    step1 = validate_input(envelope)
    if not step1.ok: return step1.payload
    step2 = verify_lineage_and_replay(envelope, execution_context_row, write_permissions, replay_registry)
    if not step2.ok: return step2.payload
    plan = build_state_update_plan(envelope, step2.payload['_execution_context_row'], write_permissions or {})
    plan['returned_step_ids'] = envelope['aggregated_result']['returned_step_ids']
    state_result = apply_execution_state_update(plan, step2.payload['_execution_context_row'])
    thread_result = apply_operational_writes(plan, thread_row)
    memory_result = persist_memory_candidates(plan, state_result.get('row_after', step2.payload['_execution_context_row']))
    audit_result = {'write_class':'audit_persistence','applied': any(item['write_class'] == 'audit_persistence' and item['allowed'] for item in plan['write_plan']),'replay_key': step2.payload['_replay_key'],'evidence_classification': {'source_verified': True,'script_verified': True,'sql_verified': True,'db_verified': False,'runtime_verified': False}}
    return build_downstream_envelope(envelope, state_result, thread_result, memory_result, audit_result=audit_result, warnings=plan['warnings'])
def sample_valid_envelope(execution_context_id: str = '33333333-3333-3333-3333-333333333333', thread_id: str = '55555555-5555-5555-5555-555555555555', tenant_id: str = '44444444-4444-4444-4444-444444444444', rollup_status: str = 'success', with_memory_candidate: bool = True) -> Dict[str, Any]:
    proposals, observations = [], []
    if with_memory_candidate:
        proposals.append({'type':'memory_candidate','category':'operational_pattern','content':'Cleaning team performs better in the morning.','confidence': 0.82})
        observations.append({'category':'supplier_signal','content':'Supplier price increase observed.','confidence': 0.74})
    return {'status_kind':'success','result_type':'aggregated_result','execution_context_id': execution_context_id,'thread_id': thread_id,'tenant_id': tenant_id,'aggregated_result': {'status': rollup_status,'summary': f'Aggregated module results with status {rollup_status}.','module_results_count': 1,'module_names': ['mem'],'per_status_counts': {'success': 1 if rollup_status == 'success' else 0,'partial': 1 if rollup_status == 'partial' else 0,'failed': 1 if rollup_status == 'failed' else 0,'no_action': 1 if rollup_status == 'no_action' else 0},'actions_executed': [],'artifacts': [],'observations': observations,'proposals': proposals,'confidence': 0.9,'needs_followup': False,'followup_requests': [],'expected_step_ids': ['s1'],'returned_step_ids': ['s1']},'state_update_allowed': True,'response_generation_allowed': False,'domain_writes_performed': False,'allowed_next_stage': 'WF-SU-01','idempotency_key': f'aggregate:{execution_context_id}'}
def sample_execution_context(execution_context_id: str = '33333333-3333-3333-3333-333333333333', thread_id: str = '55555555-5555-5555-5555-555555555555', tenant_id: str = '44444444-4444-4444-4444-444444444444', status: str = 'aggregating') -> Dict[str, Any]:
    return {'id': execution_context_id,'tenant_id': tenant_id,'thread_id': thread_id,'status': status,'current_plan_ref': 'plan-su-v1','pending_steps': ['s1'],'completed_steps': [],'module_results': [],'shared_artifacts': {},'retry_state': {'retry_allowed': False},'error_state': None}
def sample_thread(thread_id: str = '55555555-5555-5555-5555-555555555555', tenant_id: str = '44444444-4444-4444-4444-444444444444') -> Dict[str, Any]:
    return {'id': thread_id,'tenant_id': tenant_id,'status': 'active','last_activity_at': '2026-04-18T08:00:00Z'}
def sample_write_permissions() -> Dict[str, Any]:
    return {'allowed_write_classes': sorted(list(ALLOWED_WRITE_CLASSES)),'denied_write_classes': []}
