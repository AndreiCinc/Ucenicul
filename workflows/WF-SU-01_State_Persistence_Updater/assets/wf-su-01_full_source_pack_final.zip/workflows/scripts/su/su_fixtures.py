
from __future__ import annotations
from su_logic import sample_execution_context, sample_thread, sample_valid_envelope, sample_write_permissions
FIXTURE_EXECUTION_CONTEXT_ID = '33333333-3333-3333-3333-333333333333'
FIXTURE_TENANT_ID = '44444444-4444-4444-4444-444444444444'
FIXTURE_THREAD_ID = '55555555-5555-5555-5555-555555555555'
def build_fixture_bundle(rollup_status: str = 'success', with_memory_candidate: bool = True):
    return {
        'envelope': sample_valid_envelope(execution_context_id=FIXTURE_EXECUTION_CONTEXT_ID, tenant_id=FIXTURE_TENANT_ID, thread_id=FIXTURE_THREAD_ID, rollup_status=rollup_status, with_memory_candidate=with_memory_candidate),
        'execution_context_row': sample_execution_context(execution_context_id=FIXTURE_EXECUTION_CONTEXT_ID, tenant_id=FIXTURE_TENANT_ID, thread_id=FIXTURE_THREAD_ID, status='aggregating'),
        'thread_row': sample_thread(FIXTURE_THREAD_ID, FIXTURE_TENANT_ID),
        'write_permissions': sample_write_permissions(),
        'replay_registry': {},
    }
