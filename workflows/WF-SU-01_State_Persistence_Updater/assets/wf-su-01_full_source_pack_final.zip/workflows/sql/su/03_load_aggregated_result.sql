-- WF-SU-01 / 03_load_aggregated_result.sql
SELECT ec.id AS execution_context_id, ec.tenant_id, ec.thread_id, ec.module_results, ec.shared_artifacts FROM public.execution_contexts ec WHERE ec.id = $1::uuid AND ec.tenant_id = $2::uuid LIMIT 1;
