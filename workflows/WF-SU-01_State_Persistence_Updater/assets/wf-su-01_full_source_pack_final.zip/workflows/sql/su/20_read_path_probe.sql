-- WF-SU-01 / 20_read_path_probe.sql
SELECT ec.id, ec.tenant_id, ec.thread_id, ec.status, ec.current_plan_ref, ec.pending_steps, ec.completed_steps, ec.updated_at, t.status AS thread_status, t.last_activity_at FROM public.execution_contexts ec JOIN public.threads t ON t.id = ec.thread_id AND t.tenant_id = ec.tenant_id WHERE ec.id = $1::uuid AND ec.tenant_id = $2::uuid LIMIT 1;
