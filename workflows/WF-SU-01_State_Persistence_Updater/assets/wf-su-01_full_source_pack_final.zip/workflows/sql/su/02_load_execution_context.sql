-- WF-SU-01 / 02_load_execution_context.sql
SELECT ec.id, ec.tenant_id, ec.thread_id, ec.status, ec.current_plan_ref, ec.pending_steps, ec.completed_steps, ec.module_results, ec.shared_artifacts, ec.error_state, ec.retry_state, ec.updated_at FROM public.execution_contexts ec WHERE ec.id = $1::uuid AND ec.tenant_id = $2::uuid LIMIT 1;
