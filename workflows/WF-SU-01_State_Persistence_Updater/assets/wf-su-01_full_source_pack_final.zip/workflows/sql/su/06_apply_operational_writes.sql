-- WF-SU-01 / 06_apply_operational_writes.sql
WITH gate AS (SELECT $5::boolean AS apply_write)
UPDATE public.threads t
SET status = $3::text,
    last_activity_at = COALESCE($4::timestamptz, NOW()),
    updated_at = NOW()
FROM gate
WHERE gate.apply_write IS TRUE
  AND t.id = $1::uuid
  AND t.tenant_id = $2::uuid
RETURNING t.id, t.tenant_id, t.status, t.last_activity_at, t.updated_at;
