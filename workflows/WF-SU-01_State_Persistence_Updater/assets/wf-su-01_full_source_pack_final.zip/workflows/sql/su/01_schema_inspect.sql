-- WF-SU-01 / 01_schema_inspect.sql
WITH required_tables AS (
    SELECT * FROM (VALUES
        ('public', 'execution_contexts'),
        ('public', 'threads'),
        ('public', 'tasks'),
        ('public', 'reminders'),
        ('public', 'messages'),
        ('public', 'rag_memories')
    ) AS t(schema_name, table_name)
),
required_columns AS (
    SELECT * FROM (VALUES
        ('public', 'execution_contexts', 'id'),
        ('public', 'execution_contexts', 'tenant_id'),
        ('public', 'execution_contexts', 'thread_id'),
        ('public', 'execution_contexts', 'status'),
        ('public', 'execution_contexts', 'current_plan_ref'),
        ('public', 'execution_contexts', 'pending_steps'),
        ('public', 'execution_contexts', 'completed_steps'),
        ('public', 'execution_contexts', 'updated_at'),
        ('public', 'threads', 'id'),
        ('public', 'threads', 'tenant_id'),
        ('public', 'threads', 'status'),
        ('public', 'threads', 'last_activity_at')
    ) AS c(schema_name, table_name, column_name)
)
SELECT rt.schema_name, rt.table_name, EXISTS (SELECT 1 FROM information_schema.tables ist WHERE ist.table_schema = rt.schema_name AND ist.table_name = rt.table_name) AS table_exists, ARRAY(SELECT rc.column_name FROM required_columns rc WHERE rc.schema_name = rt.schema_name AND rc.table_name = rt.table_name AND NOT EXISTS (SELECT 1 FROM information_schema.columns isc WHERE isc.table_schema = rc.schema_name AND isc.table_name = rc.table_name AND isc.column_name = rc.column_name) ORDER BY rc.column_name) AS missing_columns FROM required_tables rt ORDER BY rt.table_name;
