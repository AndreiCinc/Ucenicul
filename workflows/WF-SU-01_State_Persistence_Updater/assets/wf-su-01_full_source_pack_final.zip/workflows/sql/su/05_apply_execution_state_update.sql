-- WF-SU-01 / 05_apply_execution_state_update.sql
WITH gate AS (SELECT $10::boolean AS apply_write)
UPDATE public.execution_contexts ec
SET status = $3::text,
    pending_steps = $4::jsonb,
    completed_steps = $5::jsonb,
    module_results = COALESCE($6::jsonb, ec.module_results),
    shared_artifacts = COALESCE($7::jsonb, ec.shared_artifacts),
    error_state = $8::jsonb,
    retry_state = $9::jsonb,
    updated_at = NOW()
FROM gate
WHERE gate.apply_write IS TRUE
  AND ec.id = $1::uuid
  AND ec.tenant_id = $2::uuid
RETURNING ec.id, ec.tenant_id, ec.thread_id, ec.status, ec.pending_steps, ec.completed_steps, ec.updated_at;
