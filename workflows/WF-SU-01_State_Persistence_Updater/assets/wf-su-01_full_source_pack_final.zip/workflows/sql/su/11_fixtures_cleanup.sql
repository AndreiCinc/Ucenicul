-- WF-SU-01 / 11_fixtures_cleanup.sql
DELETE FROM public.execution_contexts WHERE id = '33333333-3333-3333-3333-333333333333'::uuid;
DELETE FROM public.threads WHERE id = '55555555-5555-5555-5555-555555555555'::uuid;
