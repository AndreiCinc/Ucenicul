-- WF-SU-01 / 04_load_write_permissions.sql
SELECT $1::uuid AS tenant_id, 'WF-SU-01'::text AS execution_stage, ARRAY['execution_state_update','thread_state_update','audit_persistence','memory_candidate_persistence']::text[] AS allowed_write_classes, ARRAY[]::text[] AS denied_write_classes, NOW() AS updated_at;
