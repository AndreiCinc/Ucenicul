-- WF-SU-01 / 08_replay_guard_probe.sql
-- Optional probe only. Live replay E2E is exercised through the `_replay_seen_input_hash` envelope hook,
-- so this file stays schema-safe even when no dedicated replay ledger exists yet.
SELECT 'WF-SU-01'::text AS stage_code,
       $1::text AS idempotency_key,
       NULL::text AS input_hash,
       NULL::timestamptz AS consumed_at,
       NULL::text AS outcome_status
WHERE FALSE;
