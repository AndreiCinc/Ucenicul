-- WF-SU-01 / 07_persist_memory_candidates.sql
WITH gate AS (SELECT $4::boolean AS apply_write)
UPDATE public.execution_contexts ec
SET shared_artifacts = jsonb_set(COALESCE(ec.shared_artifacts, '{}'::jsonb), '{memory_candidates}', COALESCE($3::jsonb, '[]'::jsonb), true),
    updated_at = NOW()
FROM gate
WHERE gate.apply_write IS TRUE
  AND ec.id = $1::uuid
  AND ec.tenant_id = $2::uuid
RETURNING ec.id, ec.tenant_id, ec.shared_artifacts, ec.updated_at;
