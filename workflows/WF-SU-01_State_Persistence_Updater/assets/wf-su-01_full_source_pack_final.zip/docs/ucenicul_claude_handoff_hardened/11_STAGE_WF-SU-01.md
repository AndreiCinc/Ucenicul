# 11_STAGE_WF-SU-01 — State / Persistence Updater

## Stage identity
- Stage code: WF-SU-01
- Stage name: State / Persistence Updater
- Upstream stage: WF-RA-01
- Downstream stage: WF-RC-01
- Status: PRE_LIVE_READY
- Score cap before live proof: 9.9 / 10

## Mission
Consume one canonical `aggregated_result` envelope from WF-RA-01 and finalize persistence boundaries without generating user-facing text and without re-executing module logic.

## Strict stage scope
WF-SU-01 must:
1. accept canonical successful `aggregated_result` envelopes from WF-RA-01
2. validate lineage, tenant scoping, and replay safety
3. validate write permissions and forbid undeclared write classes
4. persist execution-context state transitions
5. apply only allowed operational writes
6. persist memory candidates for later memory-path handling
7. emit exactly one canonical `state_update_result` for WF-RC-01
8. fail closed on malformed input, lineage mismatch, replay conflict, or forbidden writes

WF-SU-01 must NOT:
- generate final user response
- re-run planning
- dispatch modules
- execute domain-module business logic
- invent success where persistence was blocked
- write outside tenant scope
- treat semantic memory as operational source of truth
- directly mutate tasks/reminders/memory store as a hidden second owner

## Canonical input contract
Top-level required fields:
- `status_kind = success`
- `result_type = aggregated_result`
- `execution_context_id`
- `thread_id`
- `tenant_id`
- `aggregated_result`
- `allowed_next_stage = WF-SU-01`
- `state_update_allowed = true`
- `response_generation_allowed = false`
- `domain_writes_performed = false`
- `idempotency_key` containing `execution_context_id`

### Test-only live hooks shipped in-pack
- `_write_permission_override.allowed_write_classes`
- `_write_permission_override.denied_write_classes`
- `_replay_seen_input_hash`

These hooks are only for live V4/V5 closure. They do not change the canonical business contract.

## Canonical output contract
Success:
- `status_kind = success`
- `result_type = state_update_result`
- `execution_context_id`
- `thread_id`
- `tenant_id`
- `state_update_result`
- `response_generation_allowed = true`
- `allowed_next_stage = WF-RC-01`
- `idempotency_key = state:<execution_context_id>`

Error:
- `status_kind = error`
- `result_type = state_update_error`
- canonical error object

## Execution lineage rules
- execution_context row MUST exist for `execution_context_id + tenant_id`
- loaded `thread_id` MUST match the envelope `thread_id`
- execution_context status MUST be legal for entry into SU (`aggregating`, `in_progress`, `planned`, `dispatching`)
- replay registry or replay hook MUST reject identical or conflicting reused idempotency keys

## Permitted write classes
- `execution_state_update`
- `thread_state_update`
- `audit_persistence`
- `memory_candidate_persistence`

## Forbidden write classes
- `response_generation`
- `module_execution`
- `plan_regeneration`
- `direct_task_business_write`
- `direct_reminder_business_write`
- `direct_memory_store_write`
- `cross_tenant_write`
- `undeclared_write_target`

## Clean ownership posture
- task/reminder business writes remain module-owned
- memory store remains memory-path-owned
- WF-SU-01 owns execution finalization, thread-state finalization, audit persistence, and memory-candidate persistence only

## Live hardening notes
- `SU_Load_Write_Permissions` emits the pack-default allowlist so the workflow remains autonomous even if no live policy table exists yet.
- denied-write tests are exercised through `_write_permission_override` and the Apply_* SQL nodes are gated to no-op on denied classes.
- partial rollup maps to canonical execution_context status `completed`.
- downstream reporting reflects the real Apply_/Persist_ node results, not hard-coded success.

## Failure behavior
- invalid input -> `INVALID_STATE_UPDATE_INPUT`
- malformed aggregated_result -> `INVALID_AGGREGATED_RESULT`
- lineage failure -> `LINEAGE_MISMATCH`
- replay failure -> `REPLAY_BLOCKED`
- undeclared write class -> `FORBIDDEN_WRITE_CLASS`
- denied state update -> `WRITE_PERMISSION_DENIED`

## Acceptance posture
This pack is pre-live ready only.
Closure requires import, shell re-read, V1–V6 runtime proof, and post-test DB drift verification.
