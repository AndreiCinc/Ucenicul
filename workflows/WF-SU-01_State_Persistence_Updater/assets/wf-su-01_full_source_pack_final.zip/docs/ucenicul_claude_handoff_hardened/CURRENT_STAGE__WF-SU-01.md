# CURRENT_STAGE — WF-SU-01 Candidate (pre_live_ready)

- Current stage: WF-SU-01
- Stage status: CANDIDATE_ACTIVE
- Posture: `pre_live_ready`
- Evidence class: source_pack_complete + script_verified (650/650) + sql_verified
- Score: 9.9 / 10
- Score cap until live proof: 9.9 / 10
- Advance allowed: false
- Closed: false

## Why this stage is active
WF-RA-01 is closed and emits the canonical `aggregated_result` envelope that WF-SU-01 is designed to consume.

## Current objective status
- source pack complete — **DONE**
- workflow JSON built — **DONE**
- SQL pack reconciled — **DONE**
- heavy deterministic tests — **DONE** (650/650 PASS)
- autonomy hardening for V4/V5 live — **DONE**
- live import — **PENDING**
- live shell re-read — **PENDING**
- live V1–V6 — **PENDING**
- post-test DB drift — **PENDING**

## Next executable action
Import the workflow, rebind Postgres, re-read the shell, then run V1–V6 using the canonical envelopes and the shipped V4/V5 live hooks.
