# 17_ACTIVE_STAGE_LOCK — WF-SU-01 Candidate Active (pre_live_ready)

LOCK_STATUS: CANDIDATE_ACTIVE
ACTIVE_STAGE: WF-SU-01
POSTURE: pre_live_ready
SCORE: 9.9 / 10
SCORE_CAP: 9.9 / 10
UPSTREAM_CLOSED_REQUIRED: WF-RA-01
DOWNSTREAM_STAGE: WF-RC-01
DOWNSTREAM_ADVANCE_ALLOWED: false
LIVE_WORKFLOW_ID: IMPORT_REQUIRED
LIVE_VERSION_ID: wf-su-01-source-pack-v1.1-hardened

## Hard rules
- Do not claim CLOSED or 10/10 before live import + runtime proof.
- Preserve RA downstream contract exactly as upstream truth for SU.
- Preserve write allowlist posture; do not silently add task/reminder/memory-store direct writes.
- Do not regress queryReplacement bindings on Postgres nodes using `$1/$2`.
- Do not attempt full-body MCP `update_workflow` / PUT after import.
- Preserve `alwaysOutputData: true` on read nodes that must fail closed on 0-row reads.
- Keep the V4/V5 live hooks intact until closure evidence is recorded.
