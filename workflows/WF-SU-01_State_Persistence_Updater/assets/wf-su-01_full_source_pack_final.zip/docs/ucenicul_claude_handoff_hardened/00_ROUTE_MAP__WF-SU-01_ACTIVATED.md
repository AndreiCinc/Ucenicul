# 00_ROUTE_MAP — WF-SU-01 Activated Candidate

## Canonical runtime route
Message In
-> WF-TR-01 Thread Resolver
-> WF-EC-01 Execution Context Init
-> WF-OR-01 Orchestrator Input Handoff
-> WF-PL-01 Plan Generation
-> WF-DI-01 Dispatcher
-> WF-ME-01 Module Execution
-> WF-RA-01 Result Aggregator
-> WF-SU-01 State + DB + Memory Update
-> WF-RC-01 Response Composer
-> Message Out

## Current route posture
- WF-TR-01: closed
- WF-EC-01: closed
- WF-OR-01: closed
- WF-PL-01: closed
- WF-DI-01: assumed upstream completed before SU activation
- WF-ME-01: assumed upstream completed before SU activation
- WF-RA-01: closed at 10/10 with canonical `aggregated_result` downstream envelope
- WF-SU-01: candidate active — posture `pre_live_ready`
- WF-RC-01 onward: not active from this pack

## Notes
WF-SU-01 consumes the canonical `aggregated_result` emitted by WF-RA-01 and emits one canonical `state_update_result` for WF-RC-01. This pack includes explicit V4/V5 live-test hooks so closure is not blocked by missing `workflow_write_policies` or `stage_idempotency_ledger` tables.
