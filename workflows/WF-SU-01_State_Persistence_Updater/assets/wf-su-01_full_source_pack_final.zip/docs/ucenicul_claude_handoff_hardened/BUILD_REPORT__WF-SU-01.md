# BUILD_REPORT — WF-SU-01

## Stage
WF-SU-01 — State / Persistence Updater

## Objective
Build a full pre-live source pack for the State / Persistence Updater that consumes the canonical WF-RA-01 `aggregated_result`, finalizes execution/thread persistence cleanly, persists memory candidates without stealing semantic-memory ownership, and emits a downstream-safe result for WF-RC-01.

## Macro build plan
1. Freeze the upstream truth from closed WF-RA-01.
2. Define the exact SU input/output contract and write boundaries.
3. Build deterministic off-node SU logic.
4. Build SQL pack with parameterized queries and explicit write allowlist posture.
5. Build workflow JSON and import/patch guide with SDK-safe hardening.
6. Build heavy deterministic tests (13 families × 50).
7. Run tests, reconcile weak files, regenerate reports, manifest, and zip.
8. Harden the pack for autonomous live closure by removing schema-only blockers and by adding explicit V4/V5 envelope hooks.

## File-by-file creation order
1. `workflows/scripts/su/su_logic.py`
2. `workflows/scripts/su/su_fixtures.py`
3. SQL pack (`01`..`20`)
4. `workflows/tests/su/test_families.py`
5. `workflows/tests/su/results/results.json`
6. `workflows/tests/su/results/results.md`
7. Workflow JSON + blueprint + maps + test matrix + patch plan
8. Stage docs + state docs + reports
9. Root handoff files + manifest + zip

## Reconciliation / hardening applied
### Cycle 1 — initial pack build
- built full source pack structure
- generated workflow JSON, SQL pack, script pack, test pack, and handoff docs
- reproduced heavy off-node suite

### Cycle 2 — autonomy hardening
- removed `__pycache__` from the handoff pack
- fixed partial rollup mapping from non-canonical `completed_with_warnings` -> canonical `completed`
- changed `SU_Load_Write_Permissions` to emit the pack-default allowlist so import does not depend on a live `workflow_write_policies` table
- added `_write_permission_override` live-test hook for V4 denied-write coverage
- added `_replay_seen_input_hash` live-test hook for V5 replay-block coverage
- gated the three Apply_/Persist_ SQL nodes so denied write classes no-op instead of mutating rows
- changed downstream envelope construction to observe the real Apply_/Persist_ node outputs instead of hard-coding success
- changed `08_replay_guard_probe.sql` to an optional schema-safe probe, not a live blocker
- reran and reproduced the heavy off-node suite at **650/650 PASS** after hardening

## Verification after build
- source pack complete: **yes**
- heavy deterministic tests: **650 / 650 PASS**
- workflow JSON shell: **17 nodes / 18 edges**
- queryReplacement preserved on Postgres nodes using `$1/$2`: **yes**
- alwaysOutputData preserved on fail-closed read nodes: **yes**
- live-proof complete: **not yet run in this pack**

## Tooling notes
- full-body workflow PUT remains forbidden post-import
- the pack is designed so Claude can close V4/V5 live without requiring extra DB schema setup first
- credentials remain placeholders in source; user rebind is still required on import

## Next executable action
Import `workflows/WF-SU-01_State_Persistence_Updater.json`, rebind Postgres, re-read the shell, then execute the V1–V6 matrix from `WF-SU-01_TEST_MATRIX.md`.
