# WF-RA-01_TEST_MATRIX

## V1 — Shell integrity
- node count = 14
- connection count = 14 (main-edge count across the graph)
- triggers present: `RA_Input`, `RA_Manual_Test_Trigger`
- switch keys `_valid` / `_context_ready`
- `RA_Load_Execution_Context.alwaysOutputData = true`
- Postgres credential binding retained and intentional

## V2 — Invalid aggregation input
- missing top-level fields
- wrong `result_type`
- missing `aggregation_input`
- invalid guard flags

## V3 — Happy path
- single success module_result
- multiple parallel success module_results
- mixed success + no_action
- flattened actions/artifacts preserved

## V4 — Malformed or incomplete module batch
- duplicate step ids
- missing expected step coverage
- malformed module_result objects
- empty module_results list

## V5 — Cross-tenant / context mismatch
- wrong tenant
- wrong thread
- missing execution_context row
- wrong execution_context id

## V6 — DB drift
- pre/post row counts unchanged
- no writes performed
- read-only SQL posture held
