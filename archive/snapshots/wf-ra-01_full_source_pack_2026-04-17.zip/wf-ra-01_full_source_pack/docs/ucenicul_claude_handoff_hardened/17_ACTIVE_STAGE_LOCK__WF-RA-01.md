# 17_ACTIVE_STAGE_LOCK — WF-RA-01 Candidate Active (pre_live_ready)

LOCK_STATUS: CANDIDATE_ACTIVE
ACTIVE_STAGE: WF-RA-01
POSTURE: pre_live_ready
UPSTREAM_CLOSED_REQUIRED: WF-ME-01
DOWNSTREAM_STAGE: WF-SU-01

## Hard rules
- WF-RA-01 is active only as a candidate source pack until live proof exists.
- No claim of 10/10 or CLOSED before live import + V1–V6 + DB drift verification.
- Do not start WF-SU-01 as active truth from this pack.
- Preserve module-result batch boundaries.
- Preserve read-only posture; no writes are allowed in this stage.
- Do not regress the reconciled connection count (14) or drop canonical SQL bridge files.
