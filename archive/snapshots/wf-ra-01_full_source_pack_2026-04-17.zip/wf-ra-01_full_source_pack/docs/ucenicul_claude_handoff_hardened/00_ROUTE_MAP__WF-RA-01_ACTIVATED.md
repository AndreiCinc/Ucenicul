# 00_ROUTE_MAP — WF-RA-01 Activated Candidate

## Canonical runtime route
Message In
-> WF-TR-01 Thread Resolver
-> WF-EC-01 Execution Context Init
-> WF-OR-01 Orchestrator Input Handoff
-> WF-PL-01 Plan Generation
-> WF-DI-01 Dispatcher
-> WF-ME-01 Module Execution
-> WF-RA-01 Result Aggregator
-> WF-SU-01 State + DB + Memory Update
-> WF-RC-01 Response Composer
-> Message Out

## Current route posture
- WF-TR-01: closed
- WF-EC-01: closed
- WF-OR-01: closed
- WF-PL-01: closed
- WF-DI-01: assumed upstream completed before RA activation
- WF-ME-01: assumed upstream completed before RA activation
- WF-RA-01: candidate active — posture `pre_live_ready` after verifier pass (not closed)
- WF-SU-01 onward: not active from this pack

## Notes
WF-RA-01 consumes canonical module-result batches and returns one canonical aggregated result.
